postTitle=raw_input("Title for this post: ")
postDesc=raw_input("Description for this post:  ")
postFile=raw_input("Filename: ")

def addpost(postTitle, postDesc, postFile):
  file=open("C:\inetpub\wwwroot\iistart.htm","a")
  file.write("""<p>"""+postTitle+"""</p>""")
  file.write("""<p>"""+postDesc+"""</p>""")
  file.write("""<a href="./reports/"""+postFile+"""">"""+postFile+"""</a>""")
  file.close()

addpost(postTitle, postDesc, postFile)